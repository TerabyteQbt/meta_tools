# This is a QBT Package Repository.

QBT is a distributed build tool.  It works by having an external metadata file in a separate repository which refers to the current commit in each package repository.  If you want to inspect this repository, or build it, you need to find the meta repository for this package repository.

If you insist upon looking at the metadata directly, try:

    git ls-remote <clone url>

And look for branches of the form "refs/qbt-pins/<SHA1>".

This branch and explanation file exists Because github insists on a repository having a "real" branch in order to be forkable.

To learn more about QBT, see [The QBT Website](http://qbtbuildtool.com)


